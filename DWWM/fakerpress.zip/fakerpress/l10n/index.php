<?php // Silence is Golden
